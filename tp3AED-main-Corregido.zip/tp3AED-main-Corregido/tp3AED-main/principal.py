from tratamientos import tratamiento


def procesar_texto(linea):
    datos = []
    campo = ""

    for c in linea:
        if c == "," or c == "\n":
            datos.append(campo)
            campo = ""
        else:
            campo += c

    if campo != "":
        datos.append(campo)

    return datos

def cargar_tratamiento(tratamientos, m):
    contador = 0
    quinto = ""

    for linea in m:
        if linea == "\n" or linea == "\r\n":
            continue

        datos = procesar_texto(linea)

        dni = int(datos[0])
        nombre = datos[1]
        apellido = datos[2]
        codigo = datos[3]
        monto_base = float(datos[4])
        complejidad = datos[5]
        id_algoritmo = int(datos[6])

        t = tratamiento(dni, nombre, apellido, codigo,
                        monto_base, complejidad, id_algoritmo)

        t.calcular_monto_final()
        tratamientos.append(t)

        if complejidad == "A":
            contador += 1

            if contador == 5:
                quinto = apellido

    print("r1.1:", len(tratamientos))

    if contador >= 5:
        print("r1.2:", quinto)
    else:
        print("r1.2: No hay suficientes tratamientos de alta complejidad.")



def mostrar_resultados(tratamientos):
    cantidad = len(tratamientos)

    if cantidad == 0:
        print("r.2.1: 0")
        print("r.2.2: No hay tratamientos.")
        print("r.2.3: 0")
        print("r.2.4: No hay tratamientos de alta complejidad.")
        return

    suma_diferencias = 0

    for t in tratamientos:
        diferencia = t.monto_final - t.monto_base
        suma_diferencias += diferencia

    promedio =suma_diferencias / cantidad

    # Frecuencia de las letras
    letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    frecuencia = [0] * 26

    for t in tratamientos:
        letra = t.obtener_letra()

        for i in range(26):
            if letra == letras[i]:
                frecuencia[i] += 1

    mayor_frecuencia = 0
    letra_mayor = ""

    for i in range(26):
        if frecuencia[i] > mayor_frecuencia:
            mayor_frecuencia = frecuencia[i]
            letra_mayor = letras[i]

    # Mayor monto final entre tratamientos de alta complejidad
    mayor_monto = 0
    dni_mayor = 0
    hay_alta = False

    for t in tratamientos:
        if t.complejidad == "A":
            if not hay_alta or t.monto_final > mayor_monto:
                mayor_monto = t.monto_final
                dni_mayor = t.dni
                hay_alta = True

    print("r.2.1:", promedio)
    print("r.2.2:", letra_mayor)
    print("r.2.3:", mayor_frecuencia)

    if hay_alta:
        print("r.2.4:", dni_mayor)
    else:
        print("r.2.4: No hay tratamientos de alta complejidad.")


def menu():
    print("1. Cargar Tratamientos")
    print("2. Mostrar Resultados")
    print("0. Salir")

    op = int(input("Ingrese opción: "))
    return op


def principal():
    tratamientos = []
    op = -1

    while op != 0:
        op = menu()

        if op == 1:
            tratamientos = []

            with open("tratamientos.csv", "rt") as m:
                m.readline()
                cargar_tratamiento(tratamientos, m)

        elif op == 2:
            mostrar_resultados(tratamientos)


if __name__ == "__main__":
    principal()