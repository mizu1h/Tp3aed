class tratamiento():
    def __init__(self, dni, nombre, apellido, icd10, monto_base,complejidad,id_algoritmo):
        self.dni = dni
        self.nombre = nombre
        self.apellido = apellido
        self.icd10 = icd10
        self.monto_base = monto_base
        self.complejidad = complejidad
        self.id_algoritmo = id_algoritmo
        self.monto_final = 0

    def obtener_letra(self):
        return self.icd10[0]

    def obtener_porcentaje(self):
        numero = 0
        despues_punto = False

        for caracter in self.icd10:
            if caracter == ".":
                despues_punto = True
            elif despues_punto:
                numero = numero * 10 + int(caracter)

        return numero
    
    def obtener_bloque(self):
        numero = 0

        for caracter in self.icd10[1:]:
            if caracter == ".":
                break
            numero = numero * 10 + int(caracter)

        return numero
    
    def calculo_normal(self):
        monto = self.monto_base + 25000
        letra = self.obtener_letra()
        if "A" <= letra <= "L":
            monto += 25000
        elif "M" <= letra <= "Z" and letra != "U":
            monto += 40000
        elif letra == "U":
            monto += 100000
        porcentaje = self.obtener_porcentaje()
        monto += monto * porcentaje / 100

        return monto

    def algoritmo_1(self):
        porcentaje_extra = 0
        suma_fija = 0

        if self.monto_base > 60000:
            porcentaje = self.obtener_porcentaje()
            porcentaje_extra = self.monto_base * porcentaje / 100

            if self.complejidad == "A" and self.obtener_letra() != "U":
                suma_fija = self.monto_base / 2

        return self.monto_base + porcentaje_extra + suma_fija

    def algoritmo_2(self):
        letra = self.obtener_letra()

        if "A" <= letra <= "P":
            porcentaje = self.obtener_porcentaje()
            porcentaje_extra = self.monto_base * porcentaje / 100

        elif self.complejidad == "A":
            porcentaje = self.obtener_porcentaje() * 2
            porcentaje_extra = self.monto_base * porcentaje / 100

        else:
            porcentaje_extra = self.monto_base * 0.15

        return self.monto_base + porcentaje_extra

    def algoritmo_3(self):
        letra = self.obtener_letra()
        monto_extra = 0

        if self.complejidad == "A":
            monto_extra = self.monto_base * 0.30

        if "A" <= letra <= "L":
            monto_extra += 20000
        elif "M" <= letra <= "P":
            bloque = self.obtener_bloque()
            monto_extra += 15000 + 5000 * bloque
        else:
            monto_extra += self.monto_base * 0.10

        if monto_extra > 60000:
            monto_extra = 60000

        return self.monto_base + monto_extra

    def calcular_monto_final(self):
        if self.id_algoritmo == 1:
            self.monto_final = self.algoritmo_1()
        elif self.id_algoritmo == 2:
            self.monto_final = self.algoritmo_2()
        elif self.id_algoritmo == 3:
            self.monto_final = self.algoritmo_3()
        else:
            self.monto_final = self.calculo_normal()

    def __str__(self):
        r = "Nombre: " + str(self.nombre)
        r += "-Apellido: " + str(self.apellido)
        r += "-ICD10: " + str(self.icd10)
        r += "-Monto Base: " + str(self.monto_base)
        r += "-Complejidad: " + str(self.complejidad)
        r += "-ID Algoritmo: " + str(self.id_algoritmo)
        r += "-Monto Final: " + str(self.monto_final)
        return r


if __name__ == "__main__":
    pass