class tratamiento():
    def __init__(self, dni, nombre, apellido, icd10, monto_base, complejidad, id_algoritmo):
        self.dni = dni
        self.nombre = nombre
        self.apellido = apellido
        self.icd10 = icd10
        self.monto_base = monto_base
        self.complejidad = complejidad
        self.id_algoritmo = id_algoritmo
        self.monto_final = 0

    def obtener_letra(self):
        return self.icd10[0]

    def obtener_porcentaje(self):
        numero = 0
        despues_punto = False

        for caracter in self.icd10:
            if caracter == ".":
                despues_punto = True
            elif despues_punto:
                numero = numero * 10 + int(caracter)

        return numero

    def obtener_bloque(self):
        numero = 0

        for caracter in self.icd10[1:]:
            if caracter == ".":
                break
            numero = numero * 10 + int(caracter)

        return numero

    def calculo_normal(self):
        # Calculo normal segun las reglas del TP1
        monto = self.monto_base + 25000
        letra = self.obtener_letra()

        if "A" <= letra <= "L":
            monto += 25000
        elif "M" <= letra <= "Z" and letra != "U":
            monto += 40000
        elif letra == "U":
            monto += 100000

        porcentaje = self.obtener_porcentaje()
        monto += monto * porcentaje / 100

        return monto

    def algoritmo_1(self):
        porcentaje_extra = 0
        suma_fija = 0

        if self.monto_base > 60000:
            porcentaje = self.obtener_porcentaje()
            porcentaje_extra = self.monto_base * porcentaje / 100

            if self.complejidad == "A" and self.obtener_letra() != "U":
                suma_fija = self.monto_base / 2

        return self.monto_base + porcentaje_extra + suma_fija

    def algoritmo_2(self):
        letra = self.obtener_letra()

        if "A" <= letra <= "P":
            porcentaje = self.obtener_porcentaje()
            porcentaje_extra = self.monto_base * porcentaje / 100

        elif self.complejidad == "A":
            porcentaje = self.obtener_porcentaje() * 2
            porcentaje_extra = self.monto_base * porcentaje / 100

        else:
            porcentaje_extra = self.monto_base * 0.15

        return self.monto_base + porcentaje_extra

    def algoritmo_3(self):
        letra = self.obtener_letra()
        monto_extra = 0

        if self.complejidad == "A":
            monto_extra = self.monto_base * 0.30

        if "A" <= letra <= "L":
            monto_extra += 20000
        elif "M" <= letra <= "P":
            bloque = self.obtener_bloque()
            monto_extra += 15000 + 5000 * bloque
        else:
            monto_extra += self.monto_base * 0.10

        if monto_extra > 60000:
            monto_extra = 60000

        return self.monto_base + monto_extra

    def calcular_monto_final(self):
        if self.id_algoritmo == 1:
            self.monto_final = self.algoritmo_1()
        elif self.id_algoritmo == 2:
            self.monto_final = self.algoritmo_2()
        elif self.id_algoritmo == 3:
            self.monto_final = self.algoritmo_3()
        else:
            self.monto_final = self.calculo_normal()

    def __str__(self):
        r = "Nombre: " + str(self.nombre)
        r += "-Apellido: " + str(self.apellido)
        r += "-ICD10: " + str(self.icd10)
        r += "-Monto Base: " + str(self.monto_base)
        r += "-Complejidad: " + str(self.complejidad)
        r += "-ID Algoritmo: " + str(self.id_algoritmo)
        r += "-Monto Final: " + str(self.monto_final)
        return r


def procesar_texto(linea):
    datos = []
    campo = ""

    for c in linea:
        if c == "," or c == "\n":
            datos.append(campo)
            campo = ""
        else:
            campo += c

    if campo != "":
        datos.append(campo)

    return datos


def cargar_tratamiento(tratamientos, m):
    contador = 0
    quinto = ""

    for linea in m:
        if linea == "\n" or linea == "\r\n":
            continue

        datos = procesar_texto(linea)

        dni = int(datos[0])
        nombre = datos[1]
        apellido = datos[2]
        codigo = datos[3]
        monto_base = float(datos[4])
        complejidad = datos[5]
        id_algoritmo = int(datos[6])

        t = tratamiento(dni, nombre, apellido, codigo,
                        monto_base, complejidad, id_algoritmo)

        t.calcular_monto_final()
        tratamientos.append(t)

        if complejidad == "A":
            contador += 1

            if contador == 5:
                quinto = apellido

    print("r1.1:", len(tratamientos))

    if contador >= 5:
        print("r1.2:", quinto)
    else:
        print("r1.2: No hay suficientes tratamientos de alta complejidad.")


def mostrar_resultados(tratamientos):
    cantidad = len(tratamientos)

    if cantidad == 0:
        print("r2.1: 0")
        print("r2.2: No hay tratamientos.")
        print("r2.3: 0")
        print("r2.4: No hay tratamientos de alta complejidad.")
        return

    suma_diferencias = 0

    for t in tratamientos:
        diferencia = t.monto_final - t.monto_base
        suma_diferencias += diferencia

    promedio = round(suma_diferencias / cantidad, 2)

    letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    frecuencia = [0] * 26

    for t in tratamientos:
        letra = t.obtener_letra()

        for i in range(26):
            if letra == letras[i]:
                frecuencia[i] += 1

    mayor_frecuencia = 0
    letra_mayor = ""

    for i in range(26):
        if frecuencia[i] > mayor_frecuencia:
            mayor_frecuencia = frecuencia[i]
            letra_mayor = letras[i]

    mayor_monto = 0
    dni_mayor = 0
    hay_alta = False

    for t in tratamientos:
        if t.complejidad == "A":
            if not hay_alta or t.monto_final > mayor_monto:
                mayor_monto = t.monto_final
                dni_mayor = t.dni
                hay_alta = True

    print("r2.1:", promedio)
    print("r2.2:", letra_mayor)
    print("r2.3:", mayor_frecuencia)

    if hay_alta:
        print("r2.4:", dni_mayor)
    else:
        print("r2.4: No hay tratamientos de alta complejidad.")


def menu():
    print("1. Cargar Tratamientos")
    print("2. Mostrar Resultados")
    print("0. Salir")

    op = int(input("Ingrese opción: "))
    return op


def principal():
    tratamientos = []
    op = -1

    while op != 0:
        op = menu()

        if op == 1:
            tratamientos = []

            with open("tratamientos.csv", "rt") as m:
                m.readline()
                cargar_tratamiento(tratamientos, m)

        elif op == 2:
            mostrar_resultados(tratamientos)


if __name__ == "__main__":
    principal()
