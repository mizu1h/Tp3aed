# La clase tratamiento y sus metodos fueron colocados en principal.py
# por solicitud del alumno.

if __name__ == "__main__":
    pass
